Nama: Fadhil Andriawan

NIM: 053497355

Program Studi: Sistem Informasi

Tugas 1 Sistem Informasi Perencanaan

Sistem Operasi: Fedora Linux

Instalasi pada Fedora linux, saya menggunakan flathub dengan melakukan instalasi dari flatpak.

> flatpak install flathub org.qgis.qgis

![install](install-1.png)

Setelah itu saya melakukan pendaftaran akun untuk mendownload data.
![daftar](daftar-2.png)

Kemudian saya mendownload data DEM pada website https://tanahair.indonesia.go.id/portal-web/unduh
![download](download-3.png)

Untuk SHP, dikarenakan website tidak bisa diakses, saya menggunakan website alternatif untuk mendownload
![download shp](download-shp-4.png)

Kemudian saya membuka aplikasi QGIS lalu menginputkan Raster dari file yang sudah didownload sebelumnya berupa DEM.
![raster](raster-5.png)

Lalu saya memasukkan vector dengan shp administrasi ar sesuai instruksi.
![vector](vector-6.png)

Setelah itu saya melakukan raster extraction pada raster yang sudah ditambahkan
![extract](extract-7.png)

Sehingga didapati hasil sebagai berikut
![result](result-8.png)

Kemudian saya merubah symbologi dengan menyesuaikan warna dari setiap nilai
![symbology](symbology-9.png)

Kemudian saya membuat print layout
![print layer](print-layer-10.png)

Saya tambahkan map yang sudah ada
![add map](add-map-11.png)

Lalu melakukan adjustment seperti coordinate, grid dan juga page setup
![adjust](adjust-12.png)

Hasil akhir didapati seperti ini
![Slope Aspect Tugas 1](Slope_Aspect_Tugas1.png)


Sumber referensi:
- https://www2.qgis.org/en/site/forusers/alldownloads.html
- https://www.indonesia-geospasial.com/2020/01/shp-rbi-provinsi-banten-perwilayah.html
